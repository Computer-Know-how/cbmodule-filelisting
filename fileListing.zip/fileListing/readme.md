File Listing Module
=================

Author
-----------------
Computer Know How, LLC/Mark Skelton

Summary
-----------------
This module will generate file listings for your ContentBox websites.

Install Instructions
-----------------
Download code and extract it to your ContentBox modules folder in the ContentBox module or install from the download manager.

Change Log
-----------------
* Version 1.0 - Initial Release
